const API = "/notices";

/* =========================
   GLOBAL USER
========================= */
let currentUser = null;

/* =========================
   INIT (IMPORTANT FIX)
========================= */
async function init() {
    await checkAuth();
    loadNotices();
}

init();

/* =========================
   AUTH CHECK
========================= */
async function checkAuth() {
    try {
        let res = await fetch("/me");
        currentUser = await res.json();

        if (!currentUser) {
            window.location.href = "login.html";
        }
    } catch {
        window.location.href = "login.html";
    }
}

/* =========================
   LOGOUT
========================= */
async function logout() {
    await fetch("/logout");
    window.location.href = "login.html";
}

/* =========================
   SECTION SWITCH
========================= */
function showSection(section) {
    let add = document.getElementById("addSection");
    let manage = document.getElementById("manageSection");

    if (!add || !manage) return;

    add.style.display = "none";
    manage.style.display = "none";

    if (section === "add") {
        add.style.display = "block";
    } else {
        manage.style.display = "block";
        loadNotices();
    }
}

/* =========================
   LOAD NOTICES
========================= */
async function loadNotices() {
    try {
        let res = await fetch(API);
        if (!res.ok) return;

        let data = await res.json();

        let searchBox = document.getElementById("search");
        let search = searchBox ? searchBox.value.toLowerCase() : "";

        let html = "";

        data
            .filter(n =>
                n.title.toLowerCase().includes(search) ||
                n.description.toLowerCase().includes(search)
            )
            .sort((a, b) => b.pinned - a.pinned)
            .forEach(n => {

                html += `
                    <div class="notice ${n.pinned ? "pinned" : ""}">
                        <h3>${n.title}</h3>
                        <p>${n.description}</p>
                        <small>${n.category} | ${n.date}</small>
                `;

                // ADMIN BUTTONS
                if (currentUser && currentUser.role === "admin") {
                    html += `
                        <br><br>

                        <button onclick="deleteNotice(${n.id})" style="background:red;">
                            Delete
                        </button>


                        <button onclick="pinNotice(${n.id})">
                            ${n.pinned ? "Unpin" : "Pin"}
                        </button>
                    `;
                }

                html += `</div>`;
            });

        document.getElementById("notices").innerHTML = html;

    } catch (err) {
        console.log("Error loading notices:", err);
    }
}

/* =========================
   HANDLE ADD + EDIT
========================= */
async function handleSubmit() {

    let id = document.getElementById("editId").value;

    let data = {
        title: document.getElementById("title").value,
        description: document.getElementById("desc").value,
        category: document.getElementById("category").value
    };

    if (!data.title || !data.description) {
        alert("Fill all fields!");
        return;
    }

    // EDIT MODE
    if (id) {
        await fetch(`${API}/${id}`, {
            method: "PUT",
            headers: {
                "Content-Type": "application/json"
            },
            body: JSON.stringify(data)
        });

        alert("Updated!");
    } 
    // ADD MODE
    else {
        await fetch(API, {
            method: "POST",
            headers: {
                "Content-Type": "application/json"
            },
            body: JSON.stringify(data)
        });

        alert("Notice Added!");
    }

    resetForm();
    loadNotices();
}

/* =========================
   EDIT (FILL FORM)
========================= */


/* =========================
   DELETE
========================= */
async function deleteNotice(id) {
    await fetch(`${API}/${id}`, {
        method: "DELETE"
    });

    loadNotices();
}

/* =========================
   PIN / UNPIN
========================= */
async function pinNotice(id) {
    await fetch(`${API}/pin/${id}`, {
        method: "PUT"
    });

    loadNotices();
}

/* =========================
   RESET FORM
========================= */
function resetForm() {
    document.getElementById("editId").value = "";
    document.getElementById("title").value = "";
    document.getElementById("desc").value = "";
    document.getElementById("submitBtn").innerText = "Add Notice";
}

/* =========================
   LIVE SEARCH
========================= */
document.addEventListener("input", (e) => {
    if (e.target.id === "search") {
        loadNotices();
    }
});