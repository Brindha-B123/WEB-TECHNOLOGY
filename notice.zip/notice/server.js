const express = require("express");
const fs = require("fs");
const cors = require("cors");
const session = require("express-session");

const app = express();

app.use(cors());
app.use(express.json());
app.use(express.static("public"));

app.use(session({
    secret: "secretkey123",
    resave: false,
    saveUninitialized: true
}));

const DB_FILE = "./db.json";
const USERS_FILE = "./users.json";

// helpers
function readDB() {
    return JSON.parse(fs.readFileSync(DB_FILE));
}

function writeDB(data) {
    fs.writeFileSync(DB_FILE, JSON.stringify(data, null, 2));
}

function readUsers() {
    return JSON.parse(fs.readFileSync(USERS_FILE));
}

/* ---------------- LOGIN ---------------- */
app.post("/login", (req, res) => {
    const { username, password } = req.body;
    const users = readUsers().users;

    const user = users.find(u =>
        u.username === username && u.password === password
    );

    if (!user) {
        return res.json({ success: false, message: "Invalid login" });
    }

    req.session.user = user;

    res.json({
        success: true,
        role: user.role
    });
});

/* ---------------- SESSION CHECK ---------------- */
app.get("/me", (req, res) => {
    res.json(req.session.user || null);
});

/* ---------------- LOGOUT ---------------- */
app.get("/logout", (req, res) => {
    req.session.destroy();
    res.json({ success: true });
});

/* ---------------- PROTECTED ROUTES ---------------- */

// Get notices (both roles)
app.get("/notices", (req, res) => {
    if (!req.session.user) return res.status(401).send("Not logged in");

    const db = readDB();
    res.json(db.notices);
});

// Add notice (admin only)
app.post("/notices", (req, res) => {
    if (!req.session.user || req.session.user.role !== "admin") {
        return res.status(403).send("Forbidden");
    }

    const db = readDB();

    const newNotice = {
        id: Date.now(),
        title: req.body.title,
        description: req.body.description,
        category: req.body.category,
        date: new Date().toLocaleString(),
        pinned: false
    };

    db.notices.push(newNotice);
    writeDB(db);

    res.json({ message: "Added" });
});

// delete (admin only)
app.delete("/notices/:id", (req, res) => {
    if (!req.session.user || req.session.user.role !== "admin") {
        return res.status(403).send("Forbidden");
    }

    let db = readDB();
    db.notices = db.notices.filter(n => n.id != req.params.id);
    writeDB(db);

    res.json({ message: "Deleted" });
});

// pin (admin only)
app.put("/notices/pin/:id", (req, res) => {
    if (!req.session.user || req.session.user.role !== "admin") {
        return res.status(403).send("Forbidden");
    }

    let db = readDB();

    db.notices = db.notices.map(n => {
        if (n.id == req.params.id) n.pinned = !n.pinned;
        return n;
    });

    writeDB(db);

    res.json({ message: "Updated" });
});


app.listen(3000, () => {
    console.log("Server running on http://localhost:3000");
});